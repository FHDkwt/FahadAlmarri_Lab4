<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiplication Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            margin-top: 20px;
        }
        td, th {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>EECS 348 Lab Four Practice Four</h1>
    <form method="post">
        <label for="size">Size of the multiplication table:</label>
        <input type="number" id="size" name="size" min="1" required>
        <button type="submit">Generate</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $size = intval($_POST["size"]);
        if ($size > 0) {
            echo "<h2>Multiplication Table ($size x $size)</h2>";
            echo "<table>";
            for ($i = 1; $i <= $size; $i++) {
                echo "<tr>";
                for ($j = 1; $j <= $size; $j++) {
                    echo "<td>" . ($i * $j) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: red;'>Please enter a valid number greater than 0.</p>";
        }
    }
    ?>
</body>
</html>